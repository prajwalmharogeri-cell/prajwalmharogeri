<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:6C63FF,50:00C8FF,100:00F5A0&height=280&section=header&text=Prajwal%20M%20Harogeri&fontSize=48&fontColor=ffffff&animation=fadeIn&fontAlignY=38&desc=Full-Stack%20Developer%20%7C%20CSE%20Student%20%7C%20Builder%20of%20Things&descAlignY=58&descSize=18"/>

<a href="https://prajwalsportfolio-fawn.vercel.app/">
  <img src="https://img.shields.io/badge/Portfolio-Visit-6C63FF?style=for-the-badge&logo=vercel&logoColor=white" />
</a>
<a href="https://www.linkedin.com/in/prajwal-m-harogeri">
  <img src="https://img.shields.io/badge/LinkedIn-Connect-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" />
</a>
<a href="mailto:prajwalmharogeri@gmail.com">
  <img src="https://img.shields.io/badge/Email-Say%20Hi-00C8FF?style=for-the-badge&logo=gmail&logoColor=white" />
</a>

<br/>

<img src="https://readme-typing-svg.herokuapp.com?font=Poppins&size=24&duration=3000&pause=1000&color=00D4FF&center=true&vCenter=true&width=850&lines=Computer+Science+Engineering+Student;Full-Stack+%2F+Frontend+Developer;Building+Nexus+%E2%80%94+a+Social+Platform;Building+OpenCue+%E2%80%94+an+Interview+Assistant;Always+Shipping%2C+Always+Learning" alt="Typing SVG" />

<img src="https://komarev.com/ghpvc/?username=prajwalmharogeri-cell&label=Profile%20Views&color=6C63FF&style=flat-square" alt="profile views"/>

</div>

<br/>

## 🧑‍💻 About Me

- 🎓 CSE (Computer Science Engineering) student at **GM University, Davanagere** — expected graduation 2029
- 💼 Currently doing a **Full-Stack Development internship** at **ElevanceSkils**
- 🚀 Building side projects independently — from social platforms to AI-assisted tools
- 🌱 Also into entrepreneurship & business strategy, and I contribute content/dev work for an NGO on the side
- 📫 Reach me at **prajwalmharogeri@gmail.com**

<br/>

## 🛠️ Tech Stack

<div align="center">

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![Vite](https://img.shields.io/badge/Vite-646CFF?style=for-the-badge&logo=vite&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![C](https://img.shields.io/badge/C-A8B9CC?style=for-the-badge&logo=c&logoColor=black)
![Supabase](https://img.shields.io/badge/Supabase-3FCF8E?style=for-the-badge&logo=supabase&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white)
![VS Code](https://img.shields.io/badge/VS%20Code-007ACC?style=for-the-badge&logo=visualstudiocode&logoColor=white)
![Vercel](https://img.shields.io/badge/Vercel-000000?style=for-the-badge&logo=vercel&logoColor=white)
![Netlify](https://img.shields.io/badge/Netlify-00C7B7?style=for-the-badge&logo=netlify&logoColor=white)

</div>

<br/>

## 🚀 Featured Projects

<div align="center">

<a href="https://my-nexus-meet.netlify.app/">
<img width="49%" src="https://github-readme-stats.vercel.app/api/pin/?username=prajwalmharogeri-cell&repo=NEXUS.app&theme=tokyonight&hide_border=true&border_radius=10" />
</a>
<a href="#">
<img width="49%" src="https://github-readme-stats.vercel.app/api/pin/?username=prajwalmharogeri-cell&repo=OpenCue&theme=tokyonight&hide_border=true&border_radius=10" />
</a>

</div>

### 🌐 Nexus — Full-Stack Social Platform
A full-stack social media web app built with **Vite + React + TypeScript + Supabase**. Features friend-count-based posting limits, subscription tiers (Free/Bronze/Silver/Gold), a points & rewards system, multi-language OTP-verified signup, and login-history security rules. Payments via Razorpay, email via Resend, SMS OTP via Twilio, rate limiting via Upstash Redis.
🔗 [Live Demo](https://my-nexus-meet.netlify.app/) · [Repo](https://github.com/prajwalmharogeri-cell/NEXUS.app)

### 🎙️ OpenCue — AI Interview Assistant
A React SPA interview assistant with a dark UI and green accents, live microphone handling, an admin dashboard, and a PhonePe QR-based INR payment flow.

### 📄 Smart Resume Analyzer
AI-powered resume screening system that parses and evaluates resumes intelligently.

### 🛋️ Furniture E-commerce Website
A modern, fully responsive furniture shopping website.

### 🖼️ Portfolio Website
Personal portfolio showcasing projects, skills, and experience.
🔗 [Visit Portfolio](https://prajwalsportfolio-fawn.vercel.app/)

<br/>

## 📊 GitHub Stats

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=prajwalmharogeri-cell&show_icons=true&theme=tokyonight&hide_border=true&count_private=true" width="49%"/>
<img src="https://github-readme-streak-stats.herokuapp.com/?user=prajwalmharogeri-cell&theme=tokyonight&hide_border=true" width="49%"/>

<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=prajwalmharogeri-cell&layout=compact&theme=tokyonight&hide_border=true" width="49%"/>

<img src="https://github-readme-activity-graph.vercel.app/graph?username=prajwalmharogeri-cell&theme=tokyo-night&hide_border=true" width="98%"/>

</div>

<br/>

## 🐍 Contribution Snake

<div align="center">
<img src="https://raw.githubusercontent.com/prajwalmharogeri-cell/prajwalmharogeri-cell/output/github-contribution-grid-snake-dark.svg" width="98%"/>
</div>

> ⚡ This snake animates your contribution graph automatically — see the **setup note** at the bottom to enable it in one click.

<br/>

## 🤝 Open To

<div align="center">

![Open Source](https://img.shields.io/badge/-Open%20Source-6C63FF?style=for-the-badge)
![Collaborations](https://img.shields.io/badge/-Collaborations-00C8FF?style=for-the-badge)
![Hackathons](https://img.shields.io/badge/-Hackathons-00F5A0?style=for-the-badge)
![Internships](https://img.shields.io/badge/-Internships-FF6B6B?style=for-the-badge)

</div>

<br/>

## 🔗 Connect With Me

<div align="center">

<a href="https://github.com/prajwalmharogeri-cell"><img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white"/></a>
<a href="https://www.linkedin.com/in/prajwal-m-harogeri"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white"/></a>
<a href="https://prajwalsportfolio-fawn.vercel.app/"><img src="https://img.shields.io/badge/Portfolio-000000?style=for-the-badge&logo=vercel&logoColor=white"/></a>
<a href="mailto:prajwalmharogeri@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white"/></a>

</div>

<br/>

<div align="center">

⭐ **Thanks for stopping by — feel free to explore my repos and reach out!**

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:00F5A0,50:00C8FF,100:6C63FF&height=120&section=footer"/>

</div>
